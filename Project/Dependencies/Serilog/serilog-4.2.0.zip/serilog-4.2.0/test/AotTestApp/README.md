
This is a test app to produce AOT warnings. To see all trim warnings, run `dotnet publish` on the current project.