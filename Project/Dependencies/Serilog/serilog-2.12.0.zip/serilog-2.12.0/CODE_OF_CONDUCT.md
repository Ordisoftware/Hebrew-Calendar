# Code of Conduct

The [Serilog Organization](https://github.com/serilog), its related [sinks][sinks] and [community projects][projects] have adopted the code of conduct defined by the [Contributor Covenant](http://contributor-covenant.org/)
to clarify expected behavior in our community.

## Attribution

The Code of Conduct referenced can be found at the [Contributor Covenant][homepage], version 1.4, available at [http://contributor-covenant.org/version/1/4][version].

[homepage]: http://contributor-covenant.org
[version]: http://contributor-covenant.org/version/1/4/
[projects]: https://github.com/serilog/serilog/wiki/Community-Projects
[sinks]: https://github.com/serilog/serilog/wiki/Provided-Sinks
