```ini

Host Process Environment Information:
BenchmarkDotNet.Core=v0.9.9.0
OS=Windows
Processor=?, ProcessorCount=8
Frequency=2533306 ticks, Resolution=394.7411 ns, Timer=TSC
CLR=CORE, Arch=64-bit ? [RyuJIT]
GC=Concurrent Workstation
dotnet cli version: 1.0.0-preview2-003121

Type=PipelineBenchmark  Mode=Throughput  

```
       Method |      Median |    StdDev |
------------- |------------ |---------- |
 EmitLogEvent | 712.9876 ns | 7.2272 ns |
