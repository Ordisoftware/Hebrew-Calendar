﻿global using System.Diagnostics.CodeAnalysis;
global using Serilog;
global using Serilog.Configuration;
global using Serilog.Core;
global using Serilog.Events;
global using Serilog.Formatting;
global using TestDummies.Console;
global using TestDummies.Console.Themes;
