namespace TestDummies.Console.Themes
{
    class ConcreteConsoleTheme : ConsoleTheme
    {
    }
}
