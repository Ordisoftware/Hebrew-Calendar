namespace TestDummies.Console.Themes
{
    public static class ConsoleThemes
    {
        public static ConsoleTheme Theme1 { get; } = new ConcreteConsoleTheme();
    }
}
