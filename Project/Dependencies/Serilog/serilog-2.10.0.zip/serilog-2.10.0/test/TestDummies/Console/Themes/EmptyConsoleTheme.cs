namespace TestDummies.Console.Themes
{
    class EmptyConsoleTheme : ConsoleTheme
    {
    }
}
