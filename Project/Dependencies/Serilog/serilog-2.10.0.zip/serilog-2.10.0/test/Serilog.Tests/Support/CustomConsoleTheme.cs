﻿using TestDummies.Console.Themes;

namespace Serilog.Tests.Support
{
    class CustomConsoleTheme : ConsoleTheme
    {
    }
}
