---
name: Usage help
about: Get help with using Serilog
title: ''
labels: invalid
assignees: ''

---

Hi! 👋

The Serilog community wants you to have a great experience using Serilog. Unfortunately, only a handful of maintainers actively follow this repository, and our time is short, so we cannot answer usage questions posted here.

Fortunately, a much larger group of people (including some of us) also watch and answer questions on the [`serilog` tag on Stack Overflow](https://stackoverflow.com/questions/tagged/serilog).

Please head over to Stack Overflow, ask your question, and tag it with `serilog`. Thanks! ❤
