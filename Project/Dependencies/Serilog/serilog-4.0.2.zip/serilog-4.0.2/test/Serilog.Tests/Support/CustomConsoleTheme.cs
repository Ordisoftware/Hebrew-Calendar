namespace Serilog.Tests.Support;

class CustomConsoleTheme : ConsoleTheme
{
}
