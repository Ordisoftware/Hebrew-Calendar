See: https://github.com/augustoproiete/NaturalStringExtensions/releases
