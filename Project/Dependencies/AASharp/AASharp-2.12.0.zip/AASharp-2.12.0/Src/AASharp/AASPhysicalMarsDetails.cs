﻿namespace AASharp
{
    public class AASPhysicalMarsDetails
    {
        public double DE { get; set; }
        public double DS { get; set; }
        public double w { get; set; }
        public double P { get; set; }
        public double X { get; set; }
        public double k { get; set; }
        public double q { get; set; }
        public double d { get; set; }
    }
}