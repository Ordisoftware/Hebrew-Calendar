﻿namespace AASharp
{
    public class AASNodeObjectDetails
    {
        public double t { get; set; }
        public double radius { get; set; }
    }
}