﻿namespace AASharp
{
    public class AASParabolicObjectElements
    {
        public double q { get; set; }
        public double i { get; set; }
        public double w { get; set; }
        public double omega { get; set; }
        public double JDEquinox { get; set; }
        public double T { get; set; }
    }
}