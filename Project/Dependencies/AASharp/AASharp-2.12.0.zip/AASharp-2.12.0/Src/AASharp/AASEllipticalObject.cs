﻿namespace AASharp
{
    public enum AASEllipticalObject
    {
        SUN,
        MERCURY,
        VENUS,
        MARS,
        JUPITER,
        SATURN,
        URANUS,
        NEPTUNE,
        PLUTO
    }
}