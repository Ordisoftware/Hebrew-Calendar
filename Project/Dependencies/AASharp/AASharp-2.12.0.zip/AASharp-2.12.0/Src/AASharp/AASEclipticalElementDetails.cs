﻿namespace AASharp
{
    public class AASEclipticalElementDetails
    {
        public double i { get; set; }
        public double w { get; set; }
        public double omega { get; set; }
    }
}