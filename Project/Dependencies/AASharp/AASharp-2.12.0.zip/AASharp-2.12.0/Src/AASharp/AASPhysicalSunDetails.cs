﻿namespace AASharp
{
    public class AASPhysicalSunDetails
    {
        public double P { get; set; }
        public double B0 { get; set; }
        public double L0 { get; set; }
    }
}