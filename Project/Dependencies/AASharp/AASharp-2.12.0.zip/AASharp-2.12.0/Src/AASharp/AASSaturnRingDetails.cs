﻿namespace AASharp
{
    public class AASSaturnRingDetails
    {
        public double B { get; set; }
        public double Bdash { get; set; }
        public double P { get; set; }
        public double a { get; set; }
        public double b { get; set; }
        public double DeltaU { get; set; }
        public double U1 { get; set; }
        public double U2 { get; set; }
    }
}