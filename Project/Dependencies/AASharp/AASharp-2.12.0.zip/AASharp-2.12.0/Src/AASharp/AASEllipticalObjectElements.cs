﻿namespace AASharp
{
    public class AASEllipticalObjectElements
    {
        public double a { get; set; }
        public double e { get; set; }
        public double i { get; set; }
        public double w { get; set; }
        public double omega { get; set; }
        public double JDEquinox { get; set; }
        public double T { get; set; }
    }
}