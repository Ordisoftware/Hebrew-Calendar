﻿namespace AASharp
{
    public class AASSaturnMoonsDetails
    {
        public AASSaturnMoonsDetails()
        {
            Satellite1 = new AASSaturnMoonDetail();
            Satellite2 = new AASSaturnMoonDetail();
            Satellite3 = new AASSaturnMoonDetail();
            Satellite4 = new AASSaturnMoonDetail();
            Satellite5 = new AASSaturnMoonDetail();
            Satellite6 = new AASSaturnMoonDetail();
            Satellite7 = new AASSaturnMoonDetail();
            Satellite8 = new AASSaturnMoonDetail();
        }

        public AASSaturnMoonDetail Satellite1 { get; set; }
        public AASSaturnMoonDetail Satellite2 { get; set; }
        public AASSaturnMoonDetail Satellite3 { get; set; }
        public AASSaturnMoonDetail Satellite4 { get; set; }
        public AASSaturnMoonDetail Satellite5 { get; set; }
        public AASSaturnMoonDetail Satellite6 { get; set; }
        public AASSaturnMoonDetail Satellite7 { get; set; }
        public AASSaturnMoonDetail Satellite8 { get; set; }
    }
}