﻿namespace AASharp
{
    public class AASPhysicalMoonDetails
    {
        public double ldash { get; set; }
        public double bdash { get; set; }
        public double ldash2 { get; set; }
        public double bdash2 { get; set; }
        public double l { get; set; }
        public double b { get; set; }
        public double P { get; set; }
    }
}