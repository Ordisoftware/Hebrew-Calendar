﻿namespace AASharp
{
    public class AASEllipticalPlanetaryDetails
    {
        public double ApparentGeocentricLongitude { get; set; }
        public double ApparentGeocentricLatitude { get; set; }
        public double ApparentGeocentricDistance { get; set; }
        public double ApparentLightTime { get; set; }
        public double ApparentGeocentricRA { get; set; }
        public double ApparentGeocentricDeclination { get; set; }
    }
}