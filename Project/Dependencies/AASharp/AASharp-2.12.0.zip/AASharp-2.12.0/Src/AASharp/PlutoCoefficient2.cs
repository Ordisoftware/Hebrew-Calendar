namespace AASharp
{
    internal struct PlutoCoefficient2
    {
        internal PlutoCoefficient2(double a, double b)
        {
            A = a;
            B = b;
        }

        public double A { get; }
        public double B { get; }
    }
}
