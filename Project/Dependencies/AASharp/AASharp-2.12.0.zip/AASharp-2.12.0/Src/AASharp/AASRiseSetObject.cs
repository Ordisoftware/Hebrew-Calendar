﻿namespace AASharp
{
    public enum AASRiseSetObject
    {
        SUN,
        MOON,
        MERCURY,
        VENUS,
        MARS,
        JUPITER,
        SATURN,
        URANUS,
        NEPTUNE,
        PLUTO,
        STAR
    };
}