namespace AASharp
{
    public class AASCalendarDate
    {
        public long Year { get; set; }
        public long Month { get; set; }
        public long Day { get; set; }
    }
}
