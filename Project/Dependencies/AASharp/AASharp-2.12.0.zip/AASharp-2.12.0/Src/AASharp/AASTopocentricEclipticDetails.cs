﻿namespace AASharp
{
    public class AASTopocentricEclipticDetails
    {
        public double Lambda { get; set; }
        public double Beta { get; set; }
        public double Semidiameter { get; set; }
    }
}