﻿namespace AASharp
{
    public class AASSelenographicMoonDetails
    {
        public double l0 { get; set; }
        public double b0 { get; set; }
        public double c0 { get; set; }
    }
}