﻿namespace AASharp
{
    public class AASPhysicalJupiterDetails
    {
        public double DE { get; set; }
        public double DS { get; set; }
        public double Geometricw1 { get; set; }
        public double Geometricw2 { get; set; }
        public double Apparentw1 { get; set; }
        public double Apparentw2 { get; set; }
        public double P { get; set; }
    }
}