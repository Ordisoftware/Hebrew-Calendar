namespace AASharp
{
    internal struct MoonCoefficient2
    {
        internal MoonCoefficient2(double a, double b)
        {
            A = a;
            B = b;
        }

        public double A { get; }
        public double B { get; }
    }
}
