namespace AASharp
{
    public class AASBinaryStarDetails
    {
        public double r { get; set; }
        public double Rho { get; set; }
        public double Theta { get; set; }
    }
}
