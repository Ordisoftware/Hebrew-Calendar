namespace AASharp
{
    public class AAS2DCoordinate
    {
        public double X { get; set; }
        public double Y { get; set; }
    }
}
