﻿namespace Humanizer.Localisation.GrammaticalNumber
{
    internal enum RussianGrammaticalNumber
    {
        Singular,
        Paucal,
        Plural
    }
}