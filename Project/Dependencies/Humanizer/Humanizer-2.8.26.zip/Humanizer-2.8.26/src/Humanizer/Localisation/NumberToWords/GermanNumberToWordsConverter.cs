﻿namespace Humanizer.Localisation.NumberToWords
{
    internal class GermanNumberToWordsConverter : GermanNumberToWordsConverterBase
    {
    }
}
