2.2.0
 - #9 - default to UTF-8 encoding without BOM

2.1.0
 - Support alternative `ITextFormatter`s through the configuration API (#4)

2.0.0 
 - Moved to new project
 - DotNet Core support
