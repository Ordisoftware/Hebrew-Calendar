﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;
using  moonr2cs;

namespace moonr2cs
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void onload(object sender, EventArgs e)
        {


            double fzone=1.0;
           System.DateTime tl = DateTime.Now;

            int fy = tl.Year;

			System.DateTime tletoz = new System.DateTime( fy, 3, 29, 23, 0, 0 ) ;
			System.DateTime tletok = new System.DateTime( fy, 10, 26, 23, 0, 0 ) ;
		
				
			if ( (DateTime.Compare(tletoz,tl ) <  0) && (DateTime.Compare(tl ,tletok) <  0) )
				fzone=2.0;


			double flat=50.05;
			double flong=14.26;
				  

			
            tday.Text=tl.Day.ToString();
            tmonth.Text=tl.Month.ToString();
            tyear.Text=tl.Year.ToString();

            tlatid.Text = System.Convert.ToString(flat);
            tlongit.Text = System.Convert.ToString(flong);
            ttzone.Text = System.Convert.ToString(fzone);
			
        }

        private void onclickcompute(object sender, EventArgs e)
        {
            float flat = System.Convert.ToSingle(tlatid.Text);
				float flong = System.Convert.ToSingle( tlongit.Text);
				float fzone =  System.Convert.ToSingle(ttzone.Text);
				int iid = System.Convert.ToInt16(tday.Text);
                int iim = System.Convert.ToInt16(tmonth.Text);
                int iiy = System.Convert.ToInt16(tyear.Text);
            
				 mr2 mujmr = new mr2();
            String systemstring;
            systemstring=mujmr.Maine2(iiy,iim,iid,flat,flong,fzone,1);
            
				int le=systemstring.Length;
                
				tresdat.Text=systemstring.Substring(0,9);
                int sssu = System.Convert.ToInt32(systemstring.Substring(10, 4) + systemstring.Substring(15, 4));
                tressun.Text = sssu.ToString("00:00/00:00");
                int sssm = System.Convert.ToInt32(systemstring.Substring(le-9, 4) + systemstring.Substring(le-4, 4));
                tresmoon.Text = sssm.ToString("00:00/00:00");
				
        }
    }
}