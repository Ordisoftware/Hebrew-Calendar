﻿namespace moonr2cs
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label1 = new System.Windows.Forms.Label();
            this.tday = new System.Windows.Forms.TextBox();
            this.tmonth = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.tyear = new System.Windows.Forms.TextBox();
            this.label3 = new System.Windows.Forms.Label();
            this.tlatid = new System.Windows.Forms.TextBox();
            this.label4 = new System.Windows.Forms.Label();
            this.tlongit = new System.Windows.Forms.TextBox();
            this.label5 = new System.Windows.Forms.Label();
            this.ttzone = new System.Windows.Forms.TextBox();
            this.label6 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.tresdat = new System.Windows.Forms.TextBox();
            this.tressun = new System.Windows.Forms.TextBox();
            this.tresmoon = new System.Windows.Forms.TextBox();
            this.label10 = new System.Windows.Forms.Label();
            this.cmdcompute = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(12, 38);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(24, 13);
            this.label1.TabIndex = 0;
            this.label1.Text = "day";
            // 
            // tday
            // 
            this.tday.Location = new System.Drawing.Point(52, 35);
            this.tday.Name = "tday";
            this.tday.Size = new System.Drawing.Size(64, 20);
            this.tday.TabIndex = 1;
            // 
            // tmonth
            // 
            this.tmonth.Location = new System.Drawing.Point(52, 75);
            this.tmonth.Name = "tmonth";
            this.tmonth.Size = new System.Drawing.Size(64, 20);
            this.tmonth.TabIndex = 3;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(12, 78);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(36, 13);
            this.label2.TabIndex = 2;
            this.label2.Text = "month";
            // 
            // tyear
            // 
            this.tyear.Location = new System.Drawing.Point(52, 119);
            this.tyear.Name = "tyear";
            this.tyear.Size = new System.Drawing.Size(64, 20);
            this.tyear.TabIndex = 5;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(12, 122);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(27, 13);
            this.label3.TabIndex = 4;
            this.label3.Text = "year";
            // 
            // tlatid
            // 
            this.tlatid.Location = new System.Drawing.Point(207, 38);
            this.tlatid.Name = "tlatid";
            this.tlatid.Size = new System.Drawing.Size(64, 20);
            this.tlatid.TabIndex = 7;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(167, 41);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(26, 13);
            this.label4.TabIndex = 6;
            this.label4.Text = "latid";
            // 
            // tlongit
            // 
            this.tlongit.Location = new System.Drawing.Point(207, 78);
            this.tlongit.Name = "tlongit";
            this.tlongit.Size = new System.Drawing.Size(64, 20);
            this.tlongit.TabIndex = 9;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(167, 81);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(32, 13);
            this.label5.TabIndex = 8;
            this.label5.Text = "longit";
            // 
            // ttzone
            // 
            this.ttzone.Location = new System.Drawing.Point(207, 122);
            this.ttzone.Name = "ttzone";
            this.ttzone.Size = new System.Drawing.Size(64, 20);
            this.ttzone.TabIndex = 11;
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(167, 125);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(33, 13);
            this.label6.TabIndex = 10;
            this.label6.Text = "tzone";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.ForeColor = System.Drawing.Color.Red;
            this.label7.Location = new System.Drawing.Point(20, 165);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(37, 13);
            this.label7.TabIndex = 12;
            this.label7.Text = "Result";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.BackColor = System.Drawing.Color.Gold;
            this.label8.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.label8.ForeColor = System.Drawing.Color.Red;
            this.label8.Location = new System.Drawing.Point(63, 165);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(83, 13);
            this.label8.TabIndex = 13;
            this.label8.Text = "Sun Rise/Set";
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.BackColor = System.Drawing.Color.Blue;
            this.label9.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.label9.ForeColor = System.Drawing.Color.WhiteSmoke;
            this.label9.Location = new System.Drawing.Point(167, 165);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(92, 13);
            this.label9.TabIndex = 14;
            this.label9.Text = "Moon Rise/Set";
            // 
            // tresdat
            // 
            this.tresdat.ForeColor = System.Drawing.Color.Red;
            this.tresdat.Location = new System.Drawing.Point(-1, 191);
            this.tresdat.Name = "tresdat";
            this.tresdat.Size = new System.Drawing.Size(58, 20);
            this.tresdat.TabIndex = 15;
            this.tresdat.Text = "yyyymmdd";
            // 
            // tressun
            // 
            this.tressun.BackColor = System.Drawing.Color.Gold;
            this.tressun.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.tressun.ForeColor = System.Drawing.Color.Red;
            this.tressun.Location = new System.Drawing.Point(66, 191);
            this.tressun.Name = "tressun";
            this.tressun.Size = new System.Drawing.Size(80, 20);
            this.tressun.TabIndex = 16;
            this.tressun.Text = "hh:hh/hh:hh";
            // 
            // tresmoon
            // 
            this.tresmoon.BackColor = System.Drawing.Color.Blue;
            this.tresmoon.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.tresmoon.ForeColor = System.Drawing.Color.White;
            this.tresmoon.Location = new System.Drawing.Point(179, 191);
            this.tresmoon.Name = "tresmoon";
            this.tresmoon.Size = new System.Drawing.Size(80, 20);
            this.tresmoon.TabIndex = 17;
            this.tresmoon.Text = "hh:hh/hh:hh";
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.label10.Location = new System.Drawing.Point(63, 9);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(171, 13);
            this.label10.TabIndex = 18;
            this.label10.Text = "Sun Monn Compute Rise/Set";
            // 
            // cmdcompute
            // 
            this.cmdcompute.Location = new System.Drawing.Point(93, 229);
            this.cmdcompute.Name = "cmdcompute";
            this.cmdcompute.Size = new System.Drawing.Size(114, 22);
            this.cmdcompute.TabIndex = 19;
            this.cmdcompute.Text = "compute";
            this.cmdcompute.UseVisualStyleBackColor = true;
            this.cmdcompute.Click += new System.EventHandler(this.onclickcompute);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(292, 266);
            this.Controls.Add(this.cmdcompute);
            this.Controls.Add(this.label10);
            this.Controls.Add(this.tresmoon);
            this.Controls.Add(this.tressun);
            this.Controls.Add(this.tresdat);
            this.Controls.Add(this.label9);
            this.Controls.Add(this.label8);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.ttzone);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.tlongit);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.tlatid);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.tyear);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.tmonth);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.tday);
            this.Controls.Add(this.label1);
            this.Name = "Form1";
            this.Text = "Sun Moon";
            this.Load += new System.EventHandler(this.onload);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox tday;
        private System.Windows.Forms.TextBox tmonth;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox tyear;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.TextBox tlatid;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.TextBox tlongit;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.TextBox ttzone;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.TextBox tresdat;
        private System.Windows.Forms.TextBox tressun;
        private System.Windows.Forms.TextBox tresmoon;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Button cmdcompute;
    }
}

