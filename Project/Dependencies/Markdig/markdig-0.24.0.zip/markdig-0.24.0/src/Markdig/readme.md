---
uid: Markdig
---

# Summary

Contains the top level classes for using Markdig. The entry user class is <xref:Markdig.Markdown>.