# Sample plain text spec

Emphasis and anchors are stripped. A newline is ensured.

```````````````````````````````` example
*Hello*, [world](http://example.com)!
.
Hello, world!

````````````````````````````````