using System.Reflection;
using System.Runtime.CompilerServices;

[assembly: AssemblyTitle("ReadText.Demo")]
[assembly: AssemblyDescription("ReadText.Demo for Command Line Parser Library")]
[assembly: AssemblyTrademark("")]
#if DEBUG
[assembly: AssemblyConfiguration("Debug")]
#else
[assembly: AssemblyConfiguration("Release")]
#endif
