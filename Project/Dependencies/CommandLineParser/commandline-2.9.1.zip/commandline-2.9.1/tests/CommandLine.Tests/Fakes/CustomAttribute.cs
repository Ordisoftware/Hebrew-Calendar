using System;

[AttributeUsage(AttributeTargets.All)]
class CustomAttribute: Attribute {}