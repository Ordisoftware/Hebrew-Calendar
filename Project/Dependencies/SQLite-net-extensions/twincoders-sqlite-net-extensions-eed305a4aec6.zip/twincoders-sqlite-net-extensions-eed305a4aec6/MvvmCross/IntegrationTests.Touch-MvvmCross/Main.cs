using UIKit;

namespace IntegrationTests.TouchMvvmCross
{
    public class Application
    {
        public static void Main(string[] args)
        {
            UIApplication.Main(args, null, nameof(AppDelegate));
        }
    }
}
