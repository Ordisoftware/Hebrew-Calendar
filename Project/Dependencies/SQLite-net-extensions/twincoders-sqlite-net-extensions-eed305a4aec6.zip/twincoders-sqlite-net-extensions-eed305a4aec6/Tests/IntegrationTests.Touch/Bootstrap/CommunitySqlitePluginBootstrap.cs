using Cirrious.CrossCore.Plugins;

namespace IntegrationTests.Touch.Bootstrap
{
    public class SqlitePluginBootstrap
        : MvxLoaderPluginBootstrapAction<Cirrious.MvvmCross.Community.Plugins.Sqlite.PluginLoader, Cirrious.MvvmCross.Community.Plugins.Sqlite.Touch.Plugin>
    {
    }
}