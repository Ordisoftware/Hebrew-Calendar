using UIKit;

namespace SQLiteNetExtensions.IntegrationTests.Touch
{
    public class Application
    {
        public static void Main(string[] args)
        {
            UIApplication.Main(args, null, nameof(AppDelegate));
        }
    }
}