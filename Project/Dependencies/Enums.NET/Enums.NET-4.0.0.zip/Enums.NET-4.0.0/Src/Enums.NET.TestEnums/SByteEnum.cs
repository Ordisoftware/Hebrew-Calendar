﻿namespace EnumsNET.Tests.TestEnums
{
    public enum SByteEnum : sbyte
    {
    }
}
