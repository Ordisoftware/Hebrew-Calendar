﻿namespace EnumsNET.Tests.TestEnums
{
    public enum Int16Enum : short
    {
    }
}
