﻿namespace EnumsNET.Tests.TestEnums
{
    public enum ByteEnum : byte
    {
    }
}
