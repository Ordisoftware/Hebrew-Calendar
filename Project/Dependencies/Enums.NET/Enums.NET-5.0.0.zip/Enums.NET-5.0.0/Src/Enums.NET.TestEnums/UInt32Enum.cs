﻿namespace EnumsNET.Tests.TestEnums;

public enum UInt32Enum : uint
{
}
