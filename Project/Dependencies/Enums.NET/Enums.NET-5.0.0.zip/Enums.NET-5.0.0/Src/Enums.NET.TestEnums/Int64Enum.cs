﻿namespace EnumsNET.Tests.TestEnums;

public enum Int64Enum : long
{
}
