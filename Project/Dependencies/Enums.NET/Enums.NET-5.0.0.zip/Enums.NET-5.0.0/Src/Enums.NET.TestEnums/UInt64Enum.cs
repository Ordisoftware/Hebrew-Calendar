﻿namespace EnumsNET.Tests.TestEnums;

public enum UInt64Enum : ulong
{
}
