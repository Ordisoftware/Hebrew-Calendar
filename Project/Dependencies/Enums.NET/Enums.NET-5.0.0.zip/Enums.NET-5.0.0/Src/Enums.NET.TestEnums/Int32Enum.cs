﻿namespace EnumsNET.Tests.TestEnums;

public enum Int32Enum
{
}
