﻿namespace EnumsNET.Tests.TestEnums
{
    public enum UInt16Enum : ushort
    {
    }
}
