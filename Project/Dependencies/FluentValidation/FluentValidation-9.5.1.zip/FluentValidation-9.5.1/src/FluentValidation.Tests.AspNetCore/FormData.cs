﻿namespace FluentValidation.Tests.AspNetCore {
	using System.Collections.Generic;

	public class FormData : Dictionary<string, string> {
	}
}
