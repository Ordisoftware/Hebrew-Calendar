pwsh -noprofile ./build.ps1 $@
