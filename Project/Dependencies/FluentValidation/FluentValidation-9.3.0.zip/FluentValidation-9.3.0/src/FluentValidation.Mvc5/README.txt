ASP.NET MVC 5 integration has been moved to https://github.com/JeremySkinner/FluentValidation-LegacyWeb
