WebApi 2 integration has been moved to https://github.com/JeremySkinner/FluentValidation-LegacyWeb
