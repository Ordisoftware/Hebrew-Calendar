###Best Practices Analyzer and Quick Fixes for the library

<img src="http://www.filehelpers.net/images/filehelpers_box_analyzer.png" />

Here is an example when using non generic version of an Engine the library suggest you to use the recommended version:

<img src="http://www.filehelpers.net/images/analyzer.gif" />

This project is open for contributions, you can check more info at www.filehelpers.net/analyzer/
