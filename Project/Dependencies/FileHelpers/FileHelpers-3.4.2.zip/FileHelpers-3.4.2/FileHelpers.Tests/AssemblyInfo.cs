using System.Reflection;

[assembly: AssemblyTitle("FileHelpers TestSuite")]
[assembly: AssemblyDelaySign(false)]
[assembly: AssemblyKeyName("")]