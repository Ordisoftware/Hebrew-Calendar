--------------------
 FileHelpers Wizard
--------------------

To run this wizard you need to have installed the .NET Framework 2.0

You can anyway generate code for both plataforms and for the 
.NET Compact Framework, but the app is written in .NET 2.0 
this is why you need it.

Cheers
Marcos