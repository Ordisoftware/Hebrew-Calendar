﻿using System.Reflection;

[assembly: AssemblyTitle("FileHelpers.FSharp.Tests")]
[assembly: AssemblyDelaySign(false)]
[assembly: AssemblyKeyName("")]
