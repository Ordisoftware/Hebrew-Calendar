﻿using System.Reflection;

[assembly: AssemblyTitle("FileHelpers ExcelNPOIStorage")]
[assembly: AssemblyDelaySign(false)]
[assembly: AssemblyKeyName("")]