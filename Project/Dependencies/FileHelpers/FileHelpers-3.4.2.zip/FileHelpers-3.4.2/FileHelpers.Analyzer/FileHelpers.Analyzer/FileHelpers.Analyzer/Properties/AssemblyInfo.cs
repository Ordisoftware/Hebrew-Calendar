﻿using System.Reflection;
using System.Runtime.InteropServices;
using FileHelpersAnalyzer;

// General Information about an assembly is controlled through the following 
// set of attributes. Change these attribute values to modify the information
// associated with an assembly.
[assembly: AssemblyTitle("FileHelpersAnalyzer")]
[assembly: AssemblyDescription("Analyzer for FileHelpers Library")]
[assembly: AssemblyConfiguration("")]
[assembly: AssemblyCompany("Devoo")]
[assembly: AssemblyProduct("FileHelpersAnalyzer")]
[assembly: AssemblyCopyright("Copyright © 2015 Devoo")]
[assembly: AssemblyTrademark("")]
[assembly: AssemblyCulture("")]

// Setting ComVisible to false makes the types in this assembly not visible 
// to COM components.  If you need to access a type in this assembly from 
// COM, set the ComVisible attribute to true on that type.
[assembly: ComVisible(false)]

// Version information for an assembly consists of the following four values:
//
//      Major Version
//      Minor Version 
//      Build Number
//      Revision
//
// You can specify all the values or you can default the Build and Revision Numbers 
// by using the '*' as shown below:


[assembly: AssemblyVersion(AnalyzerConfig.CurrentVersion)]
[assembly: AssemblyFileVersion(AnalyzerConfig.CurrentVersion)]
[assembly: AssemblyInformationalVersion(AnalyzerConfig.CurrentVersion)]

