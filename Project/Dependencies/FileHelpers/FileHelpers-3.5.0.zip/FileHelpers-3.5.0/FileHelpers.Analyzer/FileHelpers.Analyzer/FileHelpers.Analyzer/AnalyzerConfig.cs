using System;
using System.Collections;
using System.Collections.Generic;

namespace FileHelpersAnalyzer
{
    internal static class AnalyzerConfig
    {
        public const string CurrentVersion = "1.2.0";
    }
}