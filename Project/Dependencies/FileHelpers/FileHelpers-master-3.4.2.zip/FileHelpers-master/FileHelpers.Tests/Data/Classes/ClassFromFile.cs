[IgnoreFirst(1)]
[IgnoreEmptyLines()]
[DelimitedRecord("\t")]
public sealed class Tester
{
	
	public String FSA;
	
	public String TSA;
	
	public String LINE_SUBSTATION;
	
	public String DESCRIPTION;
	
	public String VOLTAGE;
	
	public String PLANT_SLOT_ID;
	
	public String NO_OF_OPERATIONS;
	
	public String Lat;
	
	public String Long;

}