namespace Meziantou.Framework.Win32;

public enum TokenElevationType
{
    Unknown = 0,
    Default = 1,
    Full = 2,
    Limited = 3,
}
