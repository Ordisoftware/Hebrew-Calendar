namespace Meziantou.Framework.Win32;

public enum TokenType
{
    TokenPrimary = 1,
    TokenImpersonation,
}
